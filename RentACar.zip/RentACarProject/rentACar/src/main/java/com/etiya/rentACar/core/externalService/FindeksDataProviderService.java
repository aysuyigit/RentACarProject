package com.etiya.rentACar.core.externalService;

public interface FindeksDataProviderService {
    int findeksPointGenerator();
}