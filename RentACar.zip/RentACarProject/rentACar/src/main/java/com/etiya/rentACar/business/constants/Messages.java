package com.etiya.rentACar.business.constants;

public class Messages {
	
	

}
