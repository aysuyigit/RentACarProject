package com.etiya.rentACar.business.externalService;

public class FakeFindeksService {
    public int getFindeksScore(int userId){
        return 900;
    }
}