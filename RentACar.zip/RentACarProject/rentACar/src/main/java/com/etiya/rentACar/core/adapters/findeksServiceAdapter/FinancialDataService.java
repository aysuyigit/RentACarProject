package com.etiya.rentACar.core.adapters.findeksServiceAdapter;

public interface FinancialDataService {
    int getFindeksScore(int userId);
}