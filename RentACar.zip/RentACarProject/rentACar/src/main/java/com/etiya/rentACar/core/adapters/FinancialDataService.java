package com.etiya.rentACar.core.adapters;

public interface FinancialDataService {
    int getFindeksScore(int userId);
}