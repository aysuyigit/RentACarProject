package com.etiya.rentACar.business.abstracts;

import com.etiya.rentACar.entities.IndividualCustomer;

public interface CustomerFindeksPointCheckService {
    int checkIndividualCustomerFindexPoint(IndividualCustomer individualCustomer);

}
